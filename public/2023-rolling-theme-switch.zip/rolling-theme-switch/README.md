# Rolling Theme Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/xxyMYKg](https://codepen.io/jkantner/pen/xxyMYKg).

A theme toggle switch based on one by [Mateusz Madura on Dribble](https://dribbble.com/shots/20239805-CopyCase-Dark-Mode-Switch) that features a mix-blend-mode-like effect for the handle and icons. The icons roll in response to the interaction.

⚠️ Since `:has()` is still experimental in Firefox as of this Pen, don’t expect it to fully work there.